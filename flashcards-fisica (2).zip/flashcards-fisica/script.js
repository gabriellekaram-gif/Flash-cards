const flashcards = [
  {
    pergunta: "O que é a reflexão da luz?",
    resposta:
      "Reflexão é o fenômeno em que a luz atinge uma superfície e retorna para o meio de onde veio. Um exemplo é o reflexo que vemos em um espelho.",
  },
  {
    pergunta: "O que é a refração da luz?",
    resposta:
      "Refração é a mudança de direção e velocidade da luz quando ela passa de um meio para outro, como quando a luz passa do ar para a água.",
  },
  {
    pergunta: "O que é a difração da luz?",
    resposta:
      "É o fenômeno em que a luz se espalha ou sofre desvios ao passar por uma abertura pequena ou contornar um obstáculo.",
  },
  {
    pergunta: "O que diz a Lei da Reflexão?",
    resposta:
      "A Lei da Reflexão estabelece que o ângulo de incidência é igual ao ângulo de reflexão: θᵢ = θᵣ.",
  },
  {
    pergunta: "Qual é a velocidade da luz no vácuo?",
    resposta:
      "A velocidade da luz no vácuo é aproximadamente 300.000 km/s, ou 3 × 10⁸ m/s.",
  },
];

const flashcard = document.getElementById("flashcard");
const questionText = document.getElementById("questionText");
const answerText = document.getElementById("answerText");
const progressFill = document.getElementById("progressFill");
const progressBar = document.getElementById("progressBar");
const counter = document.getElementById("counter");
const prevBtn = document.getElementById("prevBtn");
const nextBtn = document.getElementById("nextBtn");
const flipBtn = document.getElementById("flipBtn");

let indice = 0;
let virado = false;

function atualizarCard() {
  const atual = flashcards[indice];
  questionText.textContent = atual.pergunta;
  answerText.textContent = atual.resposta;

  const progresso = ((indice + 1) / flashcards.length) * 100;
  progressFill.style.width = `${progresso}%`;
  progressBar.setAttribute("aria-valuenow", Math.round(progresso));
  counter.textContent = `Card ${indice + 1} de ${flashcards.length}`;

  virado = false;
  flashcard.classList.remove("flipped");
}

function virarCard() {
  virado = !virado;
  flashcard.classList.toggle("flipped", virado);
}

function irParaAnterior() {
  indice = indice === 0 ? flashcards.length - 1 : indice - 1;
  atualizarCard();
}

function irParaProximo() {
  indice = indice === flashcards.length - 1 ? 0 : indice + 1;
  atualizarCard();
}

flashcard.addEventListener("click", virarCard);
flashcard.addEventListener("keydown", (event) => {
  if (event.key === "Enter" || event.key === " ") {
    event.preventDefault();
    virarCard();
  }
});

flipBtn.addEventListener("click", virarCard);
prevBtn.addEventListener("click", irParaAnterior);
nextBtn.addEventListener("click", irParaProximo);

atualizarCard();
