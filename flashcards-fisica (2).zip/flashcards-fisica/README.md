# Flashcards de Física — Fenômenos da Luz

Site estático de flashcards interativos sobre Física, com foco nos fenômenos da luz.

## Arquivos

- `index.html` — estrutura da página
- `styles.css` — estilos visuais (design simples, azul claro e azul escuro)
- `script.js` — lógica dos flashcards (navegação, virar, contador, progresso)
- `README.md` — este arquivo

## Como publicar no GitHub Pages

1. Crie um novo repositório no GitHub.
2. Envie os arquivos `index.html`, `styles.css` e `script.js` para a raiz do repositório.
3. No repositório, vá em **Settings > Pages**.
4. Em **Source**, selecione **Deploy from a branch**, escolha a branch `main` (ou `master`) e a pasta `/ (root)`.
5. Salve e aguarde alguns minutos. O link do seu site aparecerá na mesma tela.

## Funcionalidades

- 5 flashcards com perguntas e respostas sobre Física
- Clique no card ou no botão **Virar Card** para revelar a resposta
- Botões **Anterior** e **Próximo** com navegação circular
- Contador "Card X de 5"
- Barra de progresso
- Layout responsivo para computador, tablet e celular
